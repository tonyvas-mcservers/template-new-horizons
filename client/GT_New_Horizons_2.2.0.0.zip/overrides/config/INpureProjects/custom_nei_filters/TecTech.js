if (FML.isModLoaded("tectech") && tectech_enabled) {
    NEI.hide("tectech:item.em.debugContainer");
}