if (FML.isModLoaded("GraviSuite") && GraviSuite_enabled) {
    NEI.hide("GraviSuite:itemPlasmaCell");
}