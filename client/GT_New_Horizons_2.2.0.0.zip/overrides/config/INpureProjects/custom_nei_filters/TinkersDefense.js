if (FML.isModLoaded("tinkersdefense") && tinkersdefense_enabled) {
    NEI.hide("tinkersdefense:Heater Shield");
    NEI.hide("tinkersdefense:Round Shield");
}
