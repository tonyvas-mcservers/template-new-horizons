if (FML.isModLoaded("WitchingGadgets") && WitchingGadgets_enabled) {
    NEI.hide("WitchingGadgets:item.WG_Cluster");
    NEI.hide("WitchingGadgets:item.WG_CrystalFlask");
}