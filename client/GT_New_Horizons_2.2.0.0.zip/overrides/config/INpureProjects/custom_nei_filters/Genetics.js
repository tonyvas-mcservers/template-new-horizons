if (FML.isModLoaded("Genetics") && Genetics_enabled) {
    NEI.override_with_nbt("Genetics", "serum");
    NEI.override_with_nbt("Genetics", "serumArray");
}